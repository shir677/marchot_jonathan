#include <stdio.h>

int main()
{
    printf("I'm a terrible student. See? I don't know basic syntax...");
}}