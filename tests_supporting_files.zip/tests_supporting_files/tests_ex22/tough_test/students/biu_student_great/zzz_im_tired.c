#include <stdio.h>

int main()
{
	int n1, n2;
	printf("I hate recursion. Can you guess what my algorithm is?\n");
	printf("Please enter two numbers\n");
	scanf ("%d %d",&n1, &n2);
	printf("%d", n1+n2);
}
